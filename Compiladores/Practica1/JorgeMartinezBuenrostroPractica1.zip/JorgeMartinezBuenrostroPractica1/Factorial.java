class Factorial {
    public static void main( String args [ ] ) {
        int i, factn = 1;
        int numero = 5;
        for (i = 1; i <= numero; i++) {
            factn = factn ∗ i;
        }
        System.out.println(”El􏰀factorial􏰀de􏰀” + numero + ”􏰀es:􏰀” + factn);
    }
}